import 'package:flutter/material.dart';
import 'db_helper.dart';

class HistorialSumasScreen extends StatefulWidget {
  @override
  _HistorialSumasScreenState createState() => _HistorialSumasScreenState();
}

class _HistorialSumasScreenState extends State<HistorialSumasScreen> {
  final dbHelper = DBHelper();
  List<Map<String, dynamic>> sumas = [];

  @override
  void initState() {
    super.initState();
    _cargarSumas();
  }

  Future<void> _cargarSumas() async {
    final data = await dbHelper.obtenerSumas();
    setState(() {
      sumas = data;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Historial de Sumas'),
        backgroundColor: Colors.teal,
      ),
      backgroundColor: Colors.teal[100],
      body: sumas.isEmpty
          ? Center(child: Text('No hay sumas guardadas'))
          : ListView.builder(
              itemCount: sumas.length,
              itemBuilder: (context, index) {
                final suma = sumas[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: ListTile(
                    title: Text(
                      'Fecha: ${suma['fecha']}',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text('Monto: ${suma['monto']}'),
                  ),
                );
              },
            ),
    );
  }
}
