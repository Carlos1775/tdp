import 'package:flutter/material.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'db_helper.dart'; // Asegúrate de importar tu helper

class SumaValoresScreen extends StatefulWidget {
  @override
  _SumaValoresScreenState createState() => _SumaValoresScreenState();
}

class _SumaValoresScreenState extends State<SumaValoresScreen> {
  final _controller = TextEditingController();
  List<double> valores = [];
  final dbHelper = DBHelper();

  void _agregarValor() {
    final valor = double.tryParse(_controller.text);
    if (valor != null) {
      setState(() {
        valores.add(valor);
      });
      _controller.clear();
    }
  }

  Future<void> _guardarSuma() async {
    final suma = valores.fold(0.0, (a, b) => a + b);
    final fecha = DateTime.now().toString();

    // Guarda en base de datos
    await dbHelper.insertarSuma(fecha, suma);

    // Opcional: guarda en archivo también si quieres
    final dir = await getApplicationDocumentsDirectory();
    final file =
        File('${dir.path}/suma_${DateTime.now().millisecondsSinceEpoch}.txt');
    await file.writeAsString('Fecha: $fecha\nSuma: $suma');

    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Guardado en base de datos y archivo')));

    setState(() {
      valores.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sumar Valores'),
        backgroundColor: Colors.teal,
      ),
      backgroundColor: Colors.teal[100],
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Ingrese un valor',
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 60,
              child: ElevatedButton(
                onPressed: _agregarValor,
                child: Text('Agregar', style: TextStyle(fontSize: 18)),
              ),
            ),
            SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 60,
              child: ElevatedButton(
                onPressed: _guardarSuma,
                child: Text('Guardar Suma', style: TextStyle(fontSize: 18)),
              ),
            ),
            SizedBox(height: 30),
            Text(
              'Valores: ${valores.join(', ')}',
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
