import 'package:flutter/material.dart';
import 'suma_valores_screen.dart';
import 'productos_screen.dart';
import 'historial_sumas_screen.dart'; // ✅ Importa tu nueva pantalla
import 'dart:io';

class HomeScreen extends StatelessWidget {
  void _cerrarApp() {
    exit(0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Menú Principal'),
        backgroundColor: Colors.teal,
      ),
      backgroundColor: Colors.teal[100], // Fondo verde agua
      body: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // Botones principales
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: double.infinity,
                  height: 60,
                  child: ElevatedButton(
                    child: Text(
                      'Sumar Valores y Guardar',
                      style: TextStyle(fontSize: 18),
                    ),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => SumaValoresScreen()),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 60,
                  child: ElevatedButton(
                    child: Text(
                      'Gestión de Productos',
                      style: TextStyle(fontSize: 18),
                    ),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ProductosScreen()),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 60,
                  child: ElevatedButton(
                    child: Text(
                      'Ver Historial de Sumas',
                      style: TextStyle(fontSize: 18),
                    ),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => HistorialSumasScreen()),
                    ),
                  ),
                ),
              ],
            ),
            // Botón cerrar abajo
            SizedBox(
              width: double.infinity,
              height: 60,
              child: ElevatedButton(
                child: Text(
                  'Cerrar Aplicación',
                  style: TextStyle(fontSize: 18),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xfff29088),
                ),
                onPressed: _cerrarApp,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
