import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DBHelper {
  static Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDB();
    return _db!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'suma_db.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE sumas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fecha TEXT,
        monto REAL
      )
    ''');
  }

  Future<void> insertarSuma(String fecha, double monto) async {
    final db = await database;
    await db.insert(
      'sumas',
      {'fecha': fecha, 'monto': monto},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> obtenerSumas() async {
    final db = await database;
    return db.query('sumas', orderBy: 'id DESC');
  }
}
