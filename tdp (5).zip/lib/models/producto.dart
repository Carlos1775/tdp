class Producto {
  int? id;
  String codigo;
  String nombre;
  int stock;

  Producto({
    this.id,
    required this.codigo,
    required this.nombre,
    required this.stock,
  });

  factory Producto.fromMap(Map<String, dynamic> map) => Producto(
        id: map['id'],
        codigo: map['codigo'],
        nombre: map['nombre'],
        stock: map['stock'],
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'codigo': codigo,
        'nombre': nombre,
        'stock': stock,
      };
}
