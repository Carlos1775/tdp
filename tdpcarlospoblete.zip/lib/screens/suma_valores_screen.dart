import 'package:flutter/material.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class SumaValoresScreen extends StatefulWidget {
  @override
  _SumaValoresScreenState createState() => _SumaValoresScreenState();
}

class _SumaValoresScreenState extends State<SumaValoresScreen> {
  final _controller = TextEditingController();
  List<double> valores = [];

  void _agregarValor() {
    final valor = double.tryParse(_controller.text);
    if (valor != null) {
      setState(() {
        valores.add(valor);
      });
      _controller.clear();
    }
  }

  Future<void> _guardarSuma() async {
    final suma = valores.fold(0.0, (a, b) => a + b);
    final fecha = DateTime.now().toString();
    final dir = await getApplicationDocumentsDirectory();
    final file =
        File('${dir.path}/suma_${DateTime.now().millisecondsSinceEpoch}.txt');
    await file.writeAsString('Fecha: $fecha\nSuma: $suma');
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('Guardado en archivo')));
    setState(() {
      valores.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sumar Valores')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Ingrese un valor'),
            ),
            SizedBox(height: 10),
            ElevatedButton(onPressed: _agregarValor, child: Text('Agregar')),
            SizedBox(height: 10),
            ElevatedButton(
                onPressed: _guardarSuma, child: Text('Guardar Suma')),
            SizedBox(height: 20),
            Text('Valores: ${valores.join(', ')}'),
          ],
        ),
      ),
    );
  }
}
