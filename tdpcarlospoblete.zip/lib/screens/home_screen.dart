import 'package:flutter/material.dart';
import 'suma_valores_screen.dart';
import 'productos_screen.dart';
import 'dart:io';

class HomeScreen extends StatelessWidget {
  void _cerrarApp() {
    exit(0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Menú Principal')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              child: Text('Sumar Valores y Guardar'),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SumaValoresScreen()),
              ),
            ),
            ElevatedButton(
              child: Text('Gestión de Productos'),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProductosScreen()),
              ),
            ),
            ElevatedButton(
              child: Text('Cerrar Aplicación'),
              onPressed: _cerrarApp,
            ),
          ],
        ),
      ),
    );
  }
}
