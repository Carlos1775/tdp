import 'package:flutter/material.dart';
import '../services/db_service.dart';
import '../models/producto.dart';

class ProductosScreen extends StatefulWidget {
  @override
  _ProductosScreenState createState() => _ProductosScreenState();
}

class _ProductosScreenState extends State<ProductosScreen> {
  List<Producto> productos = [];
  String filtro = '';

  @override
  void initState() {
    super.initState();
    _cargarProductos();
  }

  void _cargarProductos() async {
    final datos = await DBService.db.obtenerProductos(filtro: filtro);
    setState(() {
      productos = datos;
    });
  }

  void _modificarStock(Producto producto, int cambio) async {
    await DBService.db.actualizarStock(producto.id!, cambio);
    _cargarProductos();
  }

  // Agregar un nuevo producto
  void _agregarProducto() async {
    final nombreController = TextEditingController();
    final codigoController = TextEditingController();
    final stockController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Agregar Nuevo Producto'),
        content: Column(
          children: [
            TextField(
              controller: nombreController,
              decoration: InputDecoration(labelText: 'Nombre'),
            ),
            TextField(
              controller: codigoController,
              decoration: InputDecoration(labelText: 'Código'),
            ),
            TextField(
              controller: stockController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Stock'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('Cancelar'),
          ),
          TextButton(
            onPressed: () async {
              final nombre = nombreController.text;
              final codigo = codigoController.text;
              final stock = int.tryParse(stockController.text) ?? 0;

              if (nombre.isNotEmpty && codigo.isNotEmpty && stock > 0) {
                await DBService.db.agregarProducto(nombre, codigo, stock);
                Navigator.of(context).pop();
                _cargarProductos(); // Recargar productos
              }
            },
            child: Text('Agregar'),
          ),
        ],
      ),
    );
  }

  // Eliminar un producto
  void _eliminarProducto(int id) async {
    final confirmacion = await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Confirmar Eliminación'),
        content: Text('¿Estás seguro de que quieres eliminar este producto?'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(false);
            },
            child: Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(true);
            },
            child: Text('Eliminar'),
          ),
        ],
      ),
    );

    if (confirmacion) {
      await DBService.db.eliminarProducto(id);
      _cargarProductos(); // Recargar productos
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Gestión de Productos')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Buscar por nombre o código',
                border: OutlineInputBorder(),
                suffixIcon: Icon(Icons.search),
              ),
              onChanged: (value) {
                filtro = value;
                _cargarProductos();
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 4),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Productos (${productos.length}):',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Expanded(
            child: productos.isEmpty
                ? Center(child: Text('No hay productos que coincidan.'))
                : ListView.separated(
                    separatorBuilder: (_, __) => Divider(),
                    itemCount: productos.length,
                    itemBuilder: (context, index) {
                      final prod = productos[index];
                      return ListTile(
                        title: Text('${prod.nombre}'),
                        subtitle: Text(
                            'Código: ${prod.codigo}  |  Stock: ${prod.stock}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: Icon(Icons.remove_circle_outline),
                              onPressed: () => _modificarStock(prod, -1),
                            ),
                            IconButton(
                              icon: Icon(Icons.add_circle_outline),
                              onPressed: () => _modificarStock(prod, 1),
                            ),
                            IconButton(
                              icon: Icon(Icons.delete),
                              onPressed: () => _eliminarProducto(prod.id!),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _agregarProducto,
        child: Icon(Icons.add),
      ),
    );
  }
}
